package com.example.Test2;

public class Bai1 {
    public int tinhTich(int a, int b) {
        return a * b;
    }
}